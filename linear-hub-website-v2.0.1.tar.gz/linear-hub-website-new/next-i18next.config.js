module.exports = {
  i18n: {
    defaultLocale: 'pt',
    locales: ['pt', 'en', 'es'],
    localeDetection: true,
  },
  react: {
    useSuspense: false,
  },
}
